num = int(input('Digite um número: '))
for i in range(11):
    print(f'{num} * {i} = {num * i}')