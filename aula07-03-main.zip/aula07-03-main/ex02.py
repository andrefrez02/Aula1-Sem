nome = input('Digite o seu nome: ')
idade = int(input('Digite a sua idade: '))

print(f'O Sr. {nome} tem {idade} anos de idade.')