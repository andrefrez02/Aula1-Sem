import random

var = random.randint(0, 9)
var2 = random.randint(0, 12)
var3 = random.randint(0, 24)

#print('Os valores são: ', var, ', ', var2, ', ', var3)
#print('Os valores são: %s, %s, %s ' % (var, var2, var3))
print(f'Os valores são: {var}, {var2}, {var3}')