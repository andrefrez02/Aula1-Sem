eq = input('Digite uma expressão matemática: ')
valor = eval(eq)

print(valor)