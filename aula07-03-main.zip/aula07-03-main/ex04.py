print('\nCALCULADORA\n')

n1 = float(input('Digite um valor para fazer as operações: '))
n2 = float(input('Digite outro valor para fazer as operações: '))

print(f'\nSoma: {(n1 + n2)}')
print(f'Subtração: {(n1 - n2)}')
print(f'Multiplicação: {(n1 * n2)}')
print(f'Divisão: {(n1 / n2)}')
print(f'Exponenciação: {(n1 ** n2)}')
print(f'Mod de: {(n1 % n2)}')