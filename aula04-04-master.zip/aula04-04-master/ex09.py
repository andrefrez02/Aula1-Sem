'''Faça um programa que solicite dois números reais e execute as operações
listadas a seguir de acordo com a escolha do usuário:
Escolha do usuário Operação
1 Média entre os números digitados
2 Diferença entre o maior e o menor número digitado
3 Produto entre os números digitados
4 Divisão do primeiro pelo segundo
▪ Se a opção digitada for inválida,
mostrar mensagem de erro.
▪ Na operação 4, o segundo
número não pode ser zero.'''
