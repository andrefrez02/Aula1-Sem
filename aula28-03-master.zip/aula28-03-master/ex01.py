idade = int(input('Digite a sua idade: '))
resultado = 'Pode ter CNH' if idade >= 18 else 'Não pode ter CNH'

print(resultado)