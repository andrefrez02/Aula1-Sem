horas = int(input('Entrada:\nDigite um valor em horas: '))

minutos = horas * 60

print(f'\nSaída\n{horas} horas é igual a: {minutos} minutos.')