num = int(input('Entrada:\nDigite um número inteiro: '))

print('\nSaída:')
if num > 9 or num < 0:
    print('Valor incorreto!')
else:
    print('Valor correto!')