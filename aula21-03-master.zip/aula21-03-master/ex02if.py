idade = int(input('Digite sua idade: '))

if idade <= 17:
    print('Você ainda não tem idade suficiente!')
else:
    print('Parabéns, você pode ter CNH!')

print('Obrigado por usar nosso serviço.')