num = int(input('Digite um número inteiro para saber se ele é ímpar ou par: '))

if num%2 == 0:
    print(f'{num} é um número par.')
else:
    print(f'{num} é um número ímpar')